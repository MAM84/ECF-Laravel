-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : jeu. 30 juil. 2020 à 20:40
-- Version du serveur :  10.3.23-MariaDB
-- Version de PHP : 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `bmetais_les_tresors_de_marion`
--

--
-- Déchargement des données de la table `articles`
--

INSERT INTO `articles` (`id`, `name`, `description`, `price`, `genre_id`, `substance_id`, `color_id`, `section_id`, `quantity`, `picture`, `created_at`, `updated_at`) VALUES
(1, 'Solitaire Argent Rhodie Oxyde', 'Solitaire Argent Rhodié 925/1000 Oxydes De Zirconium', 29.00, 1, 1, 1, 1, 0, '20200617152245bague1.jpg', '2020-06-17 14:10:22', '2020-07-15 22:22:47'),
(2, 'Bague Clotilde Or Blanc Et Topaze', 'Bague Or Blanc 375/1000 Diamants Topaze Bleue Forme Coeur + Diamants', 150.00, 1, 2, 1, 1, 91, '20200617152256bague2.jpg', '2020-06-17 14:10:22', '2020-07-26 16:42:19'),
(3, 'Solitaire Or Et Oxyde', 'Solitaire Or Jaune Et Oxydes De Zirconium', 229.00, 1, 2, 2, 1, 96, '20200617152312bague3.jpg', '2020-06-17 14:10:22', '2020-07-30 16:40:35'),
(4, 'Bague Or Et Diamant', 'Bague Or Blanc Et Diamants ', 119.00, 1, 2, 1, 1, 3, '20200617152333bague4.jpg', '2020-06-17 14:10:22', '2020-06-17 14:10:22'),
(5, 'Solitaire Manon Or Rose Oxyde Accompagne', 'Solitaire Or Rose 375/1000 Oxyde De Zirconium Rond 4 Griffes Accompagne Oxydes De Zirconium', 149.00, 1, 2, 3, 1, 100, '20200617152356bague5.jpg', '2020-06-17 14:10:22', '2020-06-17 14:10:22'),
(6, 'Bague Or Jaune Acier Et 1 Diamant 0.005', 'Bague Or Jaune Acier Et 1 Diamant 0.005 ', 119.00, 2, 8, 4, 1, 98, '20200617152413bague6.jpg', '2020-06-17 14:10:22', '2020-07-27 21:15:34'),
(7, 'Bague Jourdan Homme Acier Noir Anneau', 'Bague Jourdan Homme Acier Noir Anneau Interieur Acier Bleu', 69.00, 2, 5, 4, 1, 100, '20200617152434bague7.jpg', '2020-06-17 14:10:22', '2020-06-17 14:10:22'),
(8, 'Bague Nahla Or Jaune Fée', 'Bague Or Jaune 375/1000 Ajustable Fée Verte ', 59.00, 3, 2, 2, 1, 100, '20200617152452bague8.jpg', '2020-06-17 14:10:22', '2020-06-17 14:10:22'),
(9, 'Bague Or', 'Bague Or Jaune Coccinelle', 59.00, 3, 2, 2, 1, 100, '20200617152509bague9.jpg', '2020-06-17 14:10:22', '2020-06-17 14:10:22'),
(10, 'Bague Or Tricolore Ramia5 Rangs Semi', 'Bague Or Tricolore 375/1000 5 Rangs Semi Pavage Oxydes De Zirconium', 229.00, 1, 2, 5, 1, 98, '20200617152522bague10.jpg', '2020-06-17 14:10:22', '2020-07-27 21:19:43'),
(11, 'Boucles D\'oreilles Argent ', 'Boucles D\'oreilles Argent 925/1000 Pierres Bleues', 25.00, 1, 1, 1, 2, 100, '20200617154022boucles1.jpg', '2020-06-17 14:10:22', '2020-06-17 14:10:22'),
(12, 'Boucles D\'oreilles Argent Maille Torsade', 'Boucles D\'oreilles Argent 925/1000 Maille Torsade ', 35.00, 1, 1, 1, 2, 100, '20200617154031boucles2.jpg', '2020-06-17 14:10:22', '2020-06-17 14:10:22'),
(13, 'Créoles Or', 'Creoles Or Jaune 375/1000 Lisses Rondes 1.2mm Diam 55mm ', 139.00, 1, 2, 2, 2, 99, '20200617154044boucles3.jpg', '2020-06-17 14:10:22', '2020-07-27 17:47:11'),
(14, 'Boucles D\'oreilles Or Jaune Victoria Puce', 'Boucles D\'oreilles Or Jaune 750/1000 Puces Diamants 0.60cts Sertis 4 Griffes Systemes Alpas', 1990.00, 1, 3, 2, 2, 99, '20200617154056boucles4.jpg', '2020-06-17 14:10:22', '2020-07-27 22:01:21'),
(15, 'Creole Unitaire Argent Elias Croix ', 'Creole Unitaire Argent Rhodie 925/1000 Forme Croix Effet Noircis Dia 8mm', 39.00, 2, 1, 1, 2, 99, '20200617154111boucles5.jpg', '2020-06-17 14:10:22', '2020-07-27 17:51:40'),
(16, 'Boucles D\'oreille Jaune', 'Boucles D\'oreilles Or Jaune 375/1000 Et Smalto Rouge', 69.00, 3, 2, 2, 2, 98, '20200617154136boucles6.jpg', '2020-06-17 14:10:22', '2020-07-14 17:05:44'),
(17, 'Boucles D\'oreilles Argent Perles De Culture', 'Boucles D\'oreilles Argent Laury Perles De Culture Nacres 5/5,5mm Oxydes De Zirconium ', 65.00, 1, 1, 1, 2, 100, '20200617154147boucles7.jpg', '2020-06-17 14:10:22', '2020-06-17 14:10:22'),
(18, 'Boucles D\'oreilles Or Jaune Fraises', 'Boucles D\'oreilles Or Jaune 375/1000 Dormeuses Motifs Fraises Email Rouge Et Vert', 69.00, 3, 2, 2, 2, 99, '20200617154159boucles8.jpg', '2020-06-17 14:10:22', '2020-07-14 17:13:07'),
(19, 'Boucles D\'oreilles Or', 'Boucles D\'oreilles Or Jaune Poneys', 49.00, 3, 2, 2, 2, 100, '20200617154223boucles9.jpg', '2020-06-17 14:10:22', '2020-06-17 14:10:22'),
(20, 'Boucles D\'oreilles Or', 'Boucles D\'oreilles Or Blanc Saphir Et Diamants ', 469.00, 1, 2, 1, 2, 100, '20200617154242boucles10.jpg', '2020-06-17 14:10:22', '2020-06-17 14:10:22'),
(21, 'Bracelet Argent Rhodie Yalaz Double Cercle', 'Bracelet Argent Rhodie 925/1000 925/1000 Double Cercles Un Pavage Oxydes De Zirconium 18cm ', 39.00, 1, 1, 1, 3, 100, '20200617155534bracelet1.jpg', '2020-06-17 14:10:22', '2020-06-17 14:10:22'),
(22, 'Bracelet Carla Plaqué Or', 'Bracelet Plaqué Or Maille Forçat 18cm', 39.00, 1, 4, 2, 3, 95, '20200617155547bracelet2.jpg', '2020-06-17 14:10:22', '2020-07-27 17:50:24'),
(23, 'Bracelet Acier Cuir Tresse', 'Bracelet Acier Yannis Cuir Noir Et Marron Tresse 21cm ', 39.00, 2, 5, 1, 3, 100, '20200617155558bracelet3.jpg', '2020-06-17 14:10:22', '2020-06-17 14:10:22'),
(24, 'Bracelet Leana Or Rose', 'Bracelet Or Rose 375/1000 Ligne Evolutive Gravable Pastille Cordon Ajustable Fuschia', 69.00, 3, 2, 3, 3, 100, '20200617155614bracelet4.jpg', '2020-06-17 14:10:22', '2020-06-17 14:10:22'),
(25, 'Bracelet Charlie Or Jaune Girafe', 'Bracelet Or Jaune 375/1000 Girafe Sur Cordon Bleu Ajustable', 49.00, 3, 2, 2, 3, 94, '20200617155625bracelet5.jpg', '2020-06-17 14:10:22', '2020-07-30 18:20:45'),
(26, 'Bracelet Or Perle De Culture', 'Bracelet Or Jaune 375/1000 Et Perle De Culture Nacres Et Noires ', 89.00, 1, 2, 2, 3, 100, '20200617155637bracelet6.jpg', '2020-06-17 14:10:22', '2020-06-17 14:10:22'),
(27, 'Bracelet Moscou Or Blanc Riviere Diamants', 'Bracelet Or Blanc 750/1000 Riviere Diamants 17.5cm', 1990.00, 1, 3, 1, 3, 99, '20200617155649bracelet7.jpg', '2020-06-17 14:10:22', '2020-07-14 17:11:08'),
(28, 'Bracelet Acier Carbone Eff ', 'Bracelet Acier Arnaud Carbone Effet Noir 20cm', 69.00, 2, 5, 1, 3, 100, '20200617155658bracelet8.jpg', '2020-06-17 14:10:22', '2020-06-17 14:10:22'),
(29, 'Bracelet Céramique', 'Bracelet Céramique', 39.00, 1, 6, 8, 3, 100, '20200617155715bracelet9.jpg', '2020-06-17 14:10:22', '2020-06-17 14:10:22'),
(30, 'Bracelet Jonc Or Bicolore', 'Bracelet Jonc Or Bicolore 375/1000 2 Fils Flexible ', 339.00, 1, 2, 4, 3, 99, '20200617155726bracelet10.jpg', '2020-06-17 14:10:22', '2020-07-30 16:40:35'),
(31, 'Collier Argent Rhodie Cœur Oxyde', 'Collier Argent Rhodié 925/1000 Cœur Oxyde De Zirconium Central Et Oxydes De Zirconium 45cm ', 59.00, 1, 1, 1, 4, 98, '20200617160606collier1.jpg', '2020-06-17 14:10:22', '2020-07-14 16:37:16'),
(32, 'Collier Argent Rose Sacha', 'Collier Argent Rose 925/1000 Ancre Marine 42cm', 29.00, 1, 1, 3, 4, 100, '20200617160615collier2.jpg', '2020-06-17 14:10:22', '2020-06-17 14:10:22'),
(33, 'Collier Marina Or Jaune Et Diamants 42cm', 'Collier Or Jaune 375/1000 Et Diamants 42cm', 179.00, 1, 2, 2, 4, 98, '20200617160625collier3.jpg', '2020-06-17 14:10:22', '2020-07-14 16:33:11'),
(34, 'Collier Plaque Or William Grain De Cafe ', 'Collier Plaque Or Maille Grain De Cafe 9mm 60cm', 389.00, 2, 4, 2, 4, 99, '20200617160637collier4.jpg', '2020-06-17 14:10:22', '2020-07-26 15:10:23'),
(35, 'Collier Or Jaune Fleur Et Smalto 40cm', 'Collier Or Jaune 375/1000 Fleur Smalto Rose 40cm', 59.00, 3, 2, 2, 4, 96, '20200617160645collier5.jpg', '2020-06-17 14:10:22', '2020-07-30 18:20:45'),
(36, 'Collier Or Et Diamant', 'Collier Or Blanc Et Diamants Noirs Et Blancs', 199.00, 1, 2, 1, 4, 99, '20200617160657collier6.jpg', '2020-06-17 14:10:22', '2020-07-14 17:11:08'),
(37, 'Colier Marion Or Jaune', 'Collier Or Jaune 375/1000 Attrape Reve Plume Rose Et Or 38cm', 149.00, 3, 2, 2, 4, 99, '20200617160714collier7.jpg', '2020-06-17 14:10:22', '2020-07-27 17:51:06'),
(38, 'Collier Or Et Rubis', 'Collier Or Jaune Rubis Et Diamants', 279.00, 1, 2, 2, 4, 100, '20200617160732collier8.jpg', '2020-06-17 14:10:22', '2020-06-17 14:10:22'),
(39, 'Collier Acier Gouvernail', 'Collier Acier Yoan Gouvernail 50cm ', 49.00, 2, 5, 1, 4, 100, '20200617160741collier9.jpg', '2020-06-17 14:10:22', '2020-06-17 14:10:22'),
(40, 'Collier Or Jaune Poire Rubis ', 'Collier Or Jaune 375/1000 Forme Poire Rubis 43cm', 229.00, 1, 2, 2, 4, 100, '20200617160753collier10.jpg', '2020-06-17 14:10:22', '2020-06-17 14:10:22');

--
-- Déchargement des données de la table `article_order`
--

INSERT INTO `article_order` (`article_id`, `order_id`, `quantity`) VALUES
(13, 1, 1),
(6, 2, 1),
(22, 2, 1),
(37, 3, 1),
(15, 4, 1),
(6, 5, 1),
(25, 5, 1),
(10, 6, 1),
(14, 7, 1),
(3, 8, 1),
(30, 8, 1),
(35, 9, 1),
(35, 10, 1),
(35, 11, 1),
(35, 12, 1),
(25, 12, 2);

--
-- Déchargement des données de la table `colors`
--

INSERT INTO `colors` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Blanc', '2020-06-17 13:03:22', '2020-06-17 13:03:22'),
(2, 'Jaune', '2020-06-17 13:03:22', '2020-06-17 13:03:22'),
(3, 'Rose', '2020-06-17 13:03:22', '2020-06-17 13:03:22'),
(4, 'Bicolore', '2020-06-17 13:03:22', '2020-06-17 13:03:22'),
(5, 'Tricolore', '2020-06-17 13:03:22', '2020-06-17 13:03:22'),
(6, 'Jaune/Blanc', '2020-06-17 13:03:22', '2020-06-17 13:03:22'),
(7, 'Blanc/Jaune', '2020-06-17 13:03:22', '2020-06-17 13:03:22'),
(8, 'Noir', '2020-06-17 13:03:22', '2020-06-17 13:03:22'),
(9, 'Rose/Blanc', '2020-06-17 13:03:22', '2020-06-17 13:03:22'),
(10, 'Blanc/Rose', '2020-06-17 13:03:22', '2020-06-17 13:03:22'),
(11, 'Gris', '2020-06-17 13:03:22', '2020-06-17 13:03:22'),
(12, 'Autres', '2020-06-17 13:03:22', '2020-06-17 13:03:22');

--
-- Déchargement des données de la table `genres`
--

INSERT INTO `genres` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Femme', '2020-06-17 12:54:32', '2020-06-17 12:54:32'),
(2, 'Homme', '2020-06-17 12:54:32', '2020-06-17 12:54:32'),
(3, 'Enfant', '2020-06-17 12:54:32', '2020-06-17 12:54:32');

--
-- Déchargement des données de la table `notifications`
--

INSERT INTO `notifications` (`id`, `type`, `notifiable_type`, `notifiable_id`, `data`, `read_at`, `created_at`, `updated_at`) VALUES
('166a1ce3-5792-47d0-8a12-0413800f21c8', 'App\\Notifications\\NewOrder', 'App\\User', 1, '{\"id\":4,\"totalHT\":32.5,\"tva\":6.5,\"totalTTC\":39}', '2020-07-27 17:51:43', '2020-07-27 17:51:41', '2020-07-27 17:51:43'),
('21e0c925-d749-45a2-af9c-4c7993a0c294', 'App\\Notifications\\NewOrder', 'App\\User', 1, '{\"id\":28,\"totalHT\":57.5,\"tva\":11.5,\"totalTTC\":69}', '2020-07-14 17:13:23', '2020-07-14 17:13:08', '2020-07-14 17:13:23'),
('57af9b8d-3bf5-4e57-8093-73c0d5873950', 'App\\Notifications\\NewOrder', 'App\\User', 1, '{\"id\":1,\"totalHT\":115.83,\"tva\":23.17,\"totalTTC\":139}', '2020-07-27 17:47:32', '2020-07-27 17:47:13', '2020-07-27 17:47:32'),
('7ba4cefe-b4ff-4cdd-b99a-3bc15f408899', 'App\\Notifications\\NewOrder', 'App\\User', 1, '{\"id\":19,\"totalHT\":149.16666666666669,\"tva\":29.833333333333343,\"totalTTC\":179.00000000000003}', '2020-07-14 17:02:32', '2020-07-14 16:33:12', '2020-07-14 17:02:32'),
('7ebeaf4d-4ad8-4b77-a258-cb27cb2404e2', 'App\\Notifications\\NewOrder', 'App\\User', 1, '{\"id\":30,\"totalHT\":125,\"tva\":25,\"totalTTC\":150}', '2020-07-27 17:47:32', '2020-07-26 16:42:20', '2020-07-27 17:47:32'),
('7f81bb3b-d5c1-4bbc-8678-ce61eb99c412', 'App\\Notifications\\NewOrder', 'App\\User', 1, '{\"id\":29,\"totalHT\":389.17,\"tva\":77.83,\"totalTTC\":467}', '2020-07-26 15:20:01', '2020-07-26 15:10:25', '2020-07-26 15:20:01'),
('807533cf-a3ae-4b0a-841d-e4e928bf381b', 'App\\Notifications\\NewOrder', 'App\\User', 1, '{\"id\":22,\"totalHT\":40.83,\"tva\":8.17,\"totalTTC\":49,\"articles\":{\"withTimestamps\":false}}', '2020-07-14 17:02:32', '2020-07-14 16:40:27', '2020-07-14 17:02:32'),
('80fa4a3f-fe29-499b-8047-4a6b1a0b0268', 'App\\Notifications\\NewOrder', 'App\\User', 1, '{\"id\":2,\"totalHT\":131.67,\"tva\":26.33,\"totalTTC\":158}', '2020-07-27 17:50:28', '2020-07-27 17:50:26', '2020-07-27 17:50:28'),
('9193d4d3-0f56-4091-bb5d-e0a7b234e5af', 'App\\Notifications\\NewOrder', 'App\\User', 1, '{\"id\":7,\"totalHT\":1658.33,\"tva\":331.67,\"totalTTC\":1990}', '2020-07-30 16:42:58', '2020-07-27 22:01:23', '2020-07-30 16:42:58'),
('9255d6a6-4cc5-4beb-b26b-f2497a429e78', 'App\\Notifications\\NewOrder', 'App\\User', 1, '{\"id\":5,\"totalHT\":140,\"tva\":28,\"totalTTC\":168}', '2020-07-30 16:42:58', '2020-07-27 21:15:35', '2020-07-30 16:42:58'),
('986c7a58-d831-4fde-8b35-2e1c3599091c', 'App\\Notifications\\NewOrder', 'App\\User', 1, '{\"id\":11,\"totalHT\":49.17,\"tva\":9.83,\"totalTTC\":59}', '2020-07-30 18:16:49', '2020-07-30 18:09:31', '2020-07-30 18:16:49'),
('a51473dd-b82b-4f1a-92f4-84cd77ace3e4', 'App\\Notifications\\NewOrder', 'App\\User', 1, '{\"id\":12,\"totalHT\":130.83,\"tva\":26.17,\"totalTTC\":157}', NULL, '2020-07-30 18:20:46', '2020-07-30 18:20:46'),
('b24a0005-2267-468e-be94-d21f088b83c1', 'App\\Notifications\\NewOrder', 'App\\User', 1, '{\"id\":25,\"totalHT\":115,\"tva\":23,\"totalTTC\":138}', '2020-07-14 17:06:24', '2020-07-14 17:05:46', '2020-07-14 17:06:24'),
('c531385e-5e95-4b09-8320-c66947dbf4de', 'App\\Notifications\\NewOrder', 'App\\User', 1, '{\"id\":6,\"totalHT\":190.83,\"tva\":38.17,\"totalTTC\":229}', '2020-07-30 16:42:58', '2020-07-27 21:19:44', '2020-07-30 16:42:58'),
('ca07c5da-2ce5-4f33-9759-5d4fe656c1ac', 'App\\Notifications\\NewOrder', 'App\\User', 1, '{\"id\":24,\"totalHT\":32.5,\"tva\":6.5,\"totalTTC\":39}', '2020-07-14 17:02:32', '2020-07-14 16:49:05', '2020-07-14 17:02:32'),
('e1480bed-afb4-4c33-91aa-6658ea861899', 'App\\Notifications\\NewOrder', 'App\\User', 1, '{\"id\":26,\"totalHT\":231.67,\"tva\":46.33,\"totalTTC\":278}', '2020-07-14 17:11:30', '2020-07-14 17:10:01', '2020-07-14 17:11:30'),
('e9ab48b0-0517-49d1-b70e-41ba22c1b5cf', 'App\\Notifications\\NewOrder', 'App\\User', 1, '{\"id\":20,\"totalHT\":98.33,\"tva\":19.67,\"totalTTC\":118}', '2020-07-14 17:02:32', '2020-07-14 16:37:17', '2020-07-14 17:02:32'),
('fa273691-436a-47cb-8840-bc2c8e38c61a', 'App\\Notifications\\NewOrder', 'App\\User', 1, '{\"id\":27,\"totalHT\":1824.17,\"tva\":364.83,\"totalTTC\":2189}', '2020-07-14 17:11:30', '2020-07-14 17:11:09', '2020-07-14 17:11:30'),
('fcfae184-519d-47a2-a28e-63dba67d4700', 'App\\Notifications\\NewOrder', 'App\\User', 1, '{\"id\":3,\"totalHT\":124.17,\"tva\":24.83,\"totalTTC\":149}', '2020-07-27 17:51:43', '2020-07-27 17:51:08', '2020-07-27 17:51:43');

--
-- Déchargement des données de la table `orders`
--

INSERT INTO `orders` (`id`, `totalHT`, `tva`, `totalTTC`, `created_at`, `updated_at`) VALUES
(1, 115.83, 23.17, 139.00, '2020-07-27 17:47:11', '2020-07-27 17:47:11'),
(2, 131.67, 26.33, 158.00, '2020-07-27 17:50:24', '2020-07-27 17:50:24'),
(3, 124.17, 24.83, 149.00, '2020-07-27 17:51:06', '2020-07-27 17:51:06'),
(4, 32.50, 6.50, 39.00, '2020-07-27 17:51:40', '2020-07-27 17:51:40'),
(5, 140.00, 28.00, 168.00, '2020-07-27 21:15:34', '2020-07-27 21:15:34'),
(6, 190.83, 38.17, 229.00, '2020-07-27 21:19:43', '2020-07-27 21:19:43'),
(7, 1658.33, 331.67, 1990.00, '2020-07-27 22:01:21', '2020-07-27 22:01:21'),
(8, 473.33, 94.67, 568.00, '2020-07-30 16:40:35', '2020-07-30 16:40:35'),
(9, 49.17, 9.83, 59.00, '2020-07-30 17:33:37', '2020-07-30 17:33:37'),
(10, 49.17, 9.83, 59.00, '2020-07-30 17:38:12', '2020-07-30 17:38:12'),
(11, 49.17, 9.83, 59.00, '2020-07-30 18:09:31', '2020-07-30 18:09:31'),
(12, 130.83, 26.17, 157.00, '2020-07-30 18:20:45', '2020-07-30 18:20:45');

--
-- Déchargement des données de la table `sections`
--

INSERT INTO `sections` (`id`, `name`, `picture`, `created_at`, `updated_at`) VALUES
(1, 'Bagues', '20200617124645bague.jpg', '2020-06-17 12:51:44', '2020-06-17 12:51:44'),
(2, 'Boucles d’oreilles', '20200617124759boucleOreilles.jpg', '2020-06-17 12:51:44', '2020-06-17 12:51:44'),
(3, 'Bracelets', '20200617124725barcelet.jpg', '2020-06-17 12:51:44', '2020-06-17 12:51:44'),
(4, 'Colliers', '20200617124823collier.jpg', '2020-06-17 12:51:44', '2020-06-17 12:51:44');

--
-- Déchargement des données de la table `substances`
--

INSERT INTO `substances` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Argent', '2020-06-17 12:57:15', '2020-06-17 12:57:15'),
(2, 'Or 375/1000 Eme', '2020-06-17 12:57:15', '2020-06-17 12:57:15'),
(3, 'Or 750/1000 Eme', '2020-06-17 12:57:15', '2020-06-17 12:57:15'),
(4, 'Plaqué Or', '2020-06-17 12:57:15', '2020-06-17 12:57:15'),
(5, 'Acier', '2020-06-17 12:57:15', '2020-06-17 12:57:15'),
(6, 'Céramique', '2020-06-17 12:57:15', '2020-06-17 12:57:15'),
(7, 'Platine', '2020-06-17 12:57:15', '2020-06-17 12:57:15'),
(8, 'Or Acier', '2020-06-17 12:57:15', '2020-06-17 12:57:15'),
(9, 'Laiton', '2020-06-17 12:57:15', '2020-06-17 12:57:15'),
(10, 'Autre', '2020-06-17 12:57:15', '2020-06-17 12:57:15');

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `name`, `firstname`, `birthdaydate`, `phone`, `address`, `email`, `email_verified_at`, `password`, `remember_token`, `admin`, `created_at`, `updated_at`) VALUES
(1, 'Perrot', 'Dominique', '1987-08-08', '+33 (0)9 80 04 16 04', 'rue de Delannoy06694 Seguinboeuf', 'admin@admin.com', '2020-06-28 10:27:28', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'DOEhmEMwttM6HfrbNhq9e3rugaszuWDuKHxKKCdJNv6qYYnfym7TvAl6283f', 1, '2020-06-28 10:27:28', '2020-07-26 15:41:01'),
(2, 'Marechal', 'Tristan', '1987-02-16', '+33 (0)3 71 70 18 10', 'impasse Martin15306 Tessier', 'user@user.com', '2020-06-28 10:27:28', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'r8TI6KA6SzkJEAfIcKc6jtrVHT5XGOOylGFkFm78frbi40hEmIF4zBLwMZFd', 0, '2020-06-28 10:27:28', '2020-07-30 16:34:33'),
(3, 'Dupont', 'Olivier', '1989-04-29', '03 58 52 41 16', '91, rue de Chartier\n02347 Noel-sur-Berthelot', 'rturpin@example.net', '2020-06-28 10:27:28', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'mP5jrCUyOn', 0, '2020-06-28 10:27:28', '2020-06-28 10:27:28'),
(4, 'Tessier', 'Benjamin', '2009-03-08', '0133720845', '14, avenue de Duhamel\n81313 Rousseaunec', 'marty.maryse@example.net', '2020-06-28 10:27:28', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'qjuQMQuvMt', 0, '2020-06-28 10:27:28', '2020-06-28 10:27:28'),
(5, 'Martin', 'Guy', '1988-02-17', '05 22 61 21 38', '44, boulevard Sylvie Delannoy\n63389 Allard', 'denise.bazin@example.net', '2020-06-28 10:27:28', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Ce73B3Fkrt', 0, '2020-06-28 10:27:28', '2020-06-28 10:27:28'),
(6, 'Bernard', 'Arnaude', '1991-04-24', '06 92 94 78 67', '17, chemin Thomas\n65404 HerveVille', 'kcoulon@example.org', '2020-06-28 10:27:28', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'HlykqcfR3w', 0, '2020-06-28 10:27:28', '2020-06-28 10:27:28'),
(7, 'Ollivier', 'Sébastien', '1973-09-11', '+33 (0)6 21 30 25 11', '822, place Guyot\n76 488 Descamps', 'yves81@example.com', '2020-06-28 10:27:28', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '6qnMjMlVr4', 0, '2020-06-28 10:27:28', '2020-06-28 10:27:28'),
(8, 'Lecomte', 'Julie', '2012-10-12', '0476543417', 'boulevard Marc Leleu\n78863 Caron-sur-Grenier', 'thibault.patrick@example.net', '2020-06-28 10:27:28', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'yTh8U6JRJY', 0, '2020-06-28 10:27:28', '2020-06-28 10:27:28'),
(9, 'Lamy', 'Gilbert', '2005-02-22', '08 18 72 73 89', 'rue Marchal\n49 677 Pelletier', 'lopez.patricia@example.org', '2020-06-28 10:27:28', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'qK0vItpyv7', 0, '2020-06-28 10:27:28', '2020-06-28 10:27:28'),
(10, 'Gaillard', 'Victor', '2014-01-16', '+33 (0)4 95 98 61 24', '62, avenue de Olivier\n93 342 Bertinnec', 'nleger@example.net', '2020-06-28 10:27:28', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'JAnyr3yvWI', 0, '2020-06-28 10:27:28', '2020-06-28 10:27:28');

--
-- Déchargement des données de la table `user_order`
--

INSERT INTO `user_order` (`user_id`, `order_id`) VALUES
(2, 1),
(1, 2),
(1, 3),
(1, 4),
(2, 5),
(2, 6),
(2, 7),
(2, 8),
(2, 9),
(2, 10),
(2, 11),
(2, 12);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
